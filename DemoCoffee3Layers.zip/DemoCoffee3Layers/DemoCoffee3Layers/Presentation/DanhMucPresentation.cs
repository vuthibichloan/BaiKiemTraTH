﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.BUS;

namespace DemoCoffee3Layers.Presentation
{
    class DanhMucPresentation
    {
        private DanhMucBUS danhMucBUS = new DanhMucBUS();

        public void HienMenu() {
            bool end = false;
            while (!end)
            {
                Console.Clear(); //xóa màn hình

                Console.WriteLine("Quan ly danh muc");
                Console.WriteLine("1. Hien danh sach danh muc");
                Console.WriteLine("2. Them danh muc");
                Console.WriteLine("3. Sua danh muc");
                Console.WriteLine("4. Xoa danh muc");
                Console.WriteLine("5. Quay lai");
                Console.Write("Chon: ");
                string s = Console.ReadLine();
                switch (s)
                {
                    case "1": HienDanhMuc(); Console.ReadKey(); break;
                    case "2": ThemDanhMuc(); Console.ReadKey(); break;
                    case "3": SuaDanhMuc(); Console.ReadKey(); break;
                    case "4": XoaDanhMuc(); Console.ReadKey(); break;
                    case "5": end = true; break;
                }
            }
        }

        public void HienDanhMuc() {
            Console.WriteLine("Danh sach cac danh muc");
            foreach (String s in danhMucBUS.LayDanhSach())
            {
                Console.WriteLine(s);
            }
            
        }

        public void ThemDanhMuc() {
            Console.WriteLine("Nhap thong tin cho danh muc:");
            Console.Write("Ma danh muc: ");
            string ma = Console.ReadLine();
            Console.Write("Ten danh muc: ");
            string ten = Console.ReadLine();

            danhMucBUS.Them(ma, ten);
            Console.WriteLine("Da them danh muc!");
        }

        public void SuaDanhMuc() {
            Console.Write("Nhap ma danh muc can sua: ");
            string ma = Console.ReadLine();
            Console.Write("Nhap ten danh muc moi: ");
            string ten = Console.ReadLine();

            danhMucBUS.Sua(ma, ten);
            Console.WriteLine("Da sua danh muc!");
        }

        public void XoaDanhMuc()
        {
            Console.Write("Nhap ma danh muc can xoa: ");
            string ma = Console.ReadLine();

            danhMucBUS.Xoa(ma);
            Console.WriteLine("Da xoa danh muc!");
        }
    }
}
