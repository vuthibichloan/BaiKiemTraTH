﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.BUS;

namespace DemoCoffee3Layers.Presentation
{
    class BanHangPresentation
    {
        private BanHangBUS banBUS = new BanHangBUS();
        private HangHoaPresentation hhPre = new HangHoaPresentation();

        public void HienMenu()
        {
            bool end = false;
            while (!end)
            {
                Console.Clear(); //xóa màn hình

                Console.WriteLine("Quan ly hang hoa");
                Console.WriteLine("1. Hien danh sach hoa don");
                Console.WriteLine("2. Xem chi tiet hoa don");
                Console.WriteLine("3. Them hoa don");
                Console.WriteLine("4. Xoa hoa don");
                Console.WriteLine("5. Quay lai");
                Console.Write("Chon: ");
                string s = Console.ReadLine();
                switch (s)
                {
                    case "1": HienHoaDon(); Console.ReadKey(); break;
                    case "2": HienChiTietHoaDon(); Console.ReadKey(); break;
                    case "3": ThemHoaDon(); Console.ReadKey(); break;
                    case "4": XoaHoaDon(); Console.ReadKey(); break;
                    case "5": end = true; break;
                }
            }
        }

        public void HienHoaDon()
        {
            Console.WriteLine("Danh sach cac hoa don:");
            foreach (String s in banBUS.LayDanhSach())
            {
                Console.WriteLine(s);
            }
        }

        public void HienChiTietHoaDon()
        {
            Console.WriteLine("Danh sach cac hoa don:");
            foreach (String s in banBUS.LayDanhSach())
            {
                Console.WriteLine(s);
            }

            Console.Write("Nhap ma hoa don ban muon xem chi tiet: ");
            string maHD = Console.ReadLine();

            foreach (String s in banBUS.LayChiTiet(maHD))
            {
                Console.WriteLine(s);
            }
        }

        public void ThemHoaDon()
        {
            Console.WriteLine("Nhap thong tin cho hoa don:");
            Console.Write("Nhap ma hoa don: ");
            string ma = Console.ReadLine();
            Console.Write("Nhap ten khach hang: ");
            string ten = Console.ReadLine();
            Console.Write("Nhap ngay ban: ");
            string ngay = Console.ReadLine();

            banBUS.ThemHoaDon(ma, ten, ngay);

            Console.WriteLine("Nhap chi tiet hoa don: ");
            while (true) { 
                hhPre.HienHangHoa();

                Console.Write("Chon ma hang hoa: ");
                string maHH = Console.ReadLine();
                Console.Write("Nhap so luong: ");
                int soluong = int.Parse(Console.ReadLine());

                banBUS.ThemChiTiet(ma, maHH, soluong);

                Console.Write("Ban co muon nhap tiep khong (c/k): ");
                String s = Console.ReadLine();
                if (s.ToLower() != "c")
                    break;
            }

            Console.WriteLine("Da them hoa don!");
        }

        public void XoaHoaDon()
        {
            Console.Write("Nhap ma hoa don can xoa: ");
            string ma = Console.ReadLine();

            banBUS.Xoa(ma);
            Console.WriteLine("Da xoa hoa don!");
        }
    }
}
