﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DemoCoffee3Layers.DAL
{
    class DanhMucDAL
    {
        private static String FILE_NAME = "danhmuc.txt"; //File text lưu thông tin các danh mục

        public List<String> LayDanhSach() {
            StreamReader sr = new StreamReader(FILE_NAME);
            String s;
            List<String> ds = new List<string>();
            while ((s = sr.ReadLine()) != null) {
                if (string.IsNullOrEmpty(s))
                    continue;

                String[] tmp = s.Split('|'); //tách thông tin từng dòng

                String kq = tmp[0] + "\t" + tmp[1];
                ds.Add(kq); //thêm vào list kết quả

            }

            sr.Close();

            return ds;
        }

        public void Them(string maDanhMuc, string tenDanhMuc) {
            StreamWriter sw = new StreamWriter(FILE_NAME, true);

            sw.WriteLine(maDanhMuc + "|" + tenDanhMuc);

            sw.Close();
        }

        public void Sua(string maDanhMuc, string tenDanhMuc)
        {
            //ý tưởng của sửa: 
            /* ta đọc qua các dòng trong file
             * nếu gặp dòng nào có mã như vậy ta sẽ cập nhật lại thông tin mới
             * và ghi lại toàn bộ file
             */
            String kq = "";
            String s;
            StreamReader sr = new StreamReader(FILE_NAME);

            while ((s = sr.ReadLine()) != null) {
                String[] tmp = s.Split('|');

                if (tmp[0] != maDanhMuc)
                {
                    kq += s + "\n";
                }
                else {
                    //cập nhật nếu đúng mã cần sửa
                    kq += maDanhMuc + "|" + tenDanhMuc + "\n";
                }
            }

            sr.Close();

            StreamWriter sw = new StreamWriter(FILE_NAME);
            
            sw.Write(kq);

            sw.Close();
        }

        public void Xoa(string maDanhMuc)
        {
            //ý tưởng của xóa: 
            /* ta đọc qua các dòng trong file
             * nếu gặp dòng nào có mã như vậy ta sẽ bỏ qua
             * và ghi lại toàn bộ file
             */
            String kq = "";
            String s;
            StreamReader sr = new StreamReader(FILE_NAME);

            while ((s = sr.ReadLine()) != null)
            {
                String[] tmp = s.Split('|');

                if (tmp[0] != maDanhMuc)
                {
                    kq += s + "\n";
                }
            }

            sr.Close();

            StreamWriter sw = new StreamWriter(FILE_NAME);

            sw.Write(kq);

            sw.Close();
        }

    }
}
