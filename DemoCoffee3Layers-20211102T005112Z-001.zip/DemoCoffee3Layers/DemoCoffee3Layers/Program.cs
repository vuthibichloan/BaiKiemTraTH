﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.Presentation;

namespace DemoCoffee3Layers
{
    class Program
    {
        static void Main(string[] args)
        {
            bool end = false;
            while (!end)
            {
                Console.WriteLine("Quan ly cua hang coffeee");
                Console.WriteLine("1. Quan ly danh muc");
                Console.WriteLine("2. Quan ly hang hoa");
                Console.WriteLine("3. Quan ly ban hang");
                Console.WriteLine("4. Thoat");
                Console.Write("Chon: ");
                String s = Console.ReadLine();

                switch (s)
                {
                    case "1": DanhMucPresentation danhMuc = new DanhMucPresentation();
                        danhMuc.HienMenu();
                        break;
                    case "2": HangHoaPresentation hangHoa = new HangHoaPresentation();
                        hangHoa.HienMenu();
                        break;
                    case "3": BanHangPresentation banHang = new BanHangPresentation();
                        banHang.HienMenu();
                        break;
                    case "4":
                        end = true;
                        break;
                }
                Console.Clear();
            }
        }
    }
}
