﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.DAL; //sử dụng thành phần DAL

namespace DemoCoffee3Layers.BUS
{
    class DanhMucBUS
    {
        private DanhMucDAL danhMucDAL = new DanhMucDAL();

        public void Them(string maDanhMuc, string tenDanhMuc) {
            danhMucDAL.Them(maDanhMuc, tenDanhMuc);
        }

        public void Sua(string maDanhMuc, string tenDanhMuc)
        {
            danhMucDAL.Sua(maDanhMuc, tenDanhMuc);
        }

        public void Xoa(string maDanhMuc)
        {
            danhMucDAL.Xoa(maDanhMuc);
        }

        public List<String> LayDanhSach() {
            return danhMucDAL.LayDanhSach();
        }
    }
}
