﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DemoCoffee3Layers.DAL;

namespace DemoCoffee3Layers.BUS
{
    class BanHangBUS
    {
        private BanHangDAL banDAL = new BanHangDAL();

        public void ThemHoaDon(string maHD, string tenKH, string ngayBan)
        {
            banDAL.ThemHD(maHD, tenKH, ngayBan);
        }

        public void ThemChiTiet(string maHD, string maHH, int soLuong)
        {
            banDAL.ThemChiTiet(maHD, maHH, soLuong);
        }

        public void Xoa(string maHD)
        {
            banDAL.Xoa(maHD);
        }

        public List<String> LayDanhSach()
        {
            return banDAL.LayDanhSach();
        }

        public List<string> LayChiTiet(string maHD) {
            return banDAL.HienChiTiet(maHD);
        }
    }
}
