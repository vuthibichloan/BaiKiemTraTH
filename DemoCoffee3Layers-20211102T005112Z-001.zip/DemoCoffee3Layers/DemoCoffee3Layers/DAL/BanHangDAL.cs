﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DemoCoffee3Layers.DAL
{
    class BanHangDAL
    {
        private static String FILE_NAME = "banhang.txt"; //File text lưu thông tin các hóa đơn
        private static String FILE_NAME_DETAIL = "chitietbanhang.txt"; //File text lưu thông tin chi tiết của hóa đơn
        private HangHoaDAL hhDAL = new HangHoaDAL();

        public List<String> LayDanhSach()
        {
            StreamReader sr = new StreamReader(FILE_NAME);
            String s;
            List<String> ds = new List<string>();
            while ((s = sr.ReadLine()) != null)
            {
                if (string.IsNullOrEmpty(s))
                    continue;

                String[] tmp = s.Split('|'); //tách thông tin từng dòng

                String kq = tmp[0] + "\t" + tmp[1] + "\t" + tmp[2];
                ds.Add(kq); //thêm vào list kết quả
            }

            sr.Close();

            return ds;
        }

        public List<String> HienChiTiet(string maHoaDon)
        {
            StreamReader sr = new StreamReader(FILE_NAME_DETAIL);
            String s;
            List<String> ds = new List<string>();
            while ((s = sr.ReadLine()) != null)
            {
                if (string.IsNullOrEmpty(s))
                    continue;

                String[] tmp = s.Split('|'); //tách thông tin từng dòng

                if (tmp[0] == maHoaDon)
                {
                    String kq = hhDAL.LayThongTin(tmp[1]) + "\t So luong: " + tmp[2];
                    ds.Add(kq); //thêm vào list kết quả
                }
            }

            sr.Close();

            return ds;
        }

        public void ThemHD(string maHD, string tenKH, String ngay)
        {
            StreamWriter sw = new StreamWriter(FILE_NAME, true);

            sw.WriteLine(maHD + "|" + tenKH + "|" + ngay);

            sw.Close();
        }

        public void ThemChiTiet(string maHD, string maHH, int soLuong)
        {
            StreamWriter sw = new StreamWriter(FILE_NAME_DETAIL, true);

            sw.WriteLine(maHD + "|" + maHH + "|" + soLuong);

            sw.Close();
        }

        public void Xoa(string maHD)
        {
            //ý tưởng của xóa: 
            /* ta đọc qua các dòng trong file
             * nếu gặp dòng nào có mã như vậy ta sẽ bỏ qua
             * và ghi lại toàn bộ file
             */
            String kq = "";
            String s;
            StreamReader sr = new StreamReader(FILE_NAME);

            while ((s = sr.ReadLine()) != null)
            {
                String[] tmp = s.Split('|');

                if (tmp[0] != maHD)
                {
                    kq += s + "\n";
                }
            }
            sr.Close();

            StreamWriter sw = new StreamWriter(FILE_NAME);
            sw.Write(kq);
            sw.Close();

            kq = "";
            sr = new StreamReader(FILE_NAME_DETAIL);

            while ((s = sr.ReadLine()) != null)
            {
                String[] tmp = s.Split('|');

                if (tmp[0] != maHD)
                {
                    kq += s + "\n";
                }
            }
            sr.Close();

            sw = new StreamWriter(FILE_NAME_DETAIL);
            sw.Write(kq);
            sw.Close();
        }
    }
}
