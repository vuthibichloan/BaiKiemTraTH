﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DemoCoffee3Layers.DAL
{
    class HangHoaDAL
    {
        private static String FILE_NAME = "hanghoa.txt"; //File text lưu thông tin các danh mục

        public List<String> LayDanhSach()
        {
            StreamReader sr = new StreamReader(FILE_NAME);
            String s;
            List<String> ds = new List<string>();
            while ((s = sr.ReadLine()) != null)
            {
                if (string.IsNullOrEmpty(s))
                    continue;

                String[] tmp = s.Split('|'); //tách thông tin từng dòng

                String kq = tmp[0] + "\t" + tmp[1] + "\t" + tmp[2] + "\t" + tmp[3];
                ds.Add(kq); //thêm vào list kết quả

            }

            sr.Close();

            return ds;
        }

        public void Them(string maHH, string tenHH, int giaBan, String maDanhMuc)
        {
            StreamWriter sw = new StreamWriter(FILE_NAME, true);

            sw.WriteLine(maHH + "|" + tenHH + "|" + giaBan + "|" + maDanhMuc);

            sw.Close();
        }

        public void Sua(string maHH, string tenHH, int giaBan, String maDanhMuc)
        {
            //ý tưởng của sửa: 
            /* ta đọc qua các dòng trong file
             * nếu gặp dòng nào có mã như vậy ta sẽ cập nhật lại thông tin mới
             * và ghi lại toàn bộ file
             */
            String kq = "";
            String s;
            StreamReader sr = new StreamReader(FILE_NAME);

            while ((s = sr.ReadLine()) != null)
            {
                String[] tmp = s.Split('|');

                if (tmp[0] != maDanhMuc)
                {
                    kq += s + "\n";
                }
                else
                {
                    //cập nhật nếu đúng mã cần sửa
                    kq += maHH + "|" + tenHH + "|" + giaBan + "|" + maDanhMuc + "\n";
                }
            }

            sr.Close();

            StreamWriter sw = new StreamWriter(FILE_NAME);

            sw.Write(kq);

            sw.Close();
        }

        public void Xoa(string maHH)
        {
            //ý tưởng của xóa: 
            /* ta đọc qua các dòng trong file
             * nếu gặp dòng nào có mã như vậy ta sẽ bỏ qua
             * và ghi lại toàn bộ file
             */
            String kq = "";
            String s;
            StreamReader sr = new StreamReader(FILE_NAME);

            while ((s = sr.ReadLine()) != null)
            {
                String[] tmp = s.Split('|');

                if (tmp[0] != maHH)
                {
                    kq += s + "\n";
                }
            }

            sr.Close();

            StreamWriter sw = new StreamWriter(FILE_NAME);

            sw.Write(kq);

            sw.Close();
        }

        public String LayThongTin(string maHH) {
            StreamReader sr = new StreamReader(FILE_NAME);
            String s;
            String kq = "";
            while ((s = sr.ReadLine()) != null)
            {
                if (string.IsNullOrEmpty(s))
                    continue;

                String[] tmp = s.Split('|'); //tách thông tin từng dòng
                if (tmp[0] == maHH)
                    kq = tmp[0] + "\t" + tmp[1] + "\t" + tmp[2] + "\t" + tmp[3];
            }

            sr.Close();

            return kq;
        }
    }
}
